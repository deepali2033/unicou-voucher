@extends('layouts.master')

@section('title', 'Disputes & Refunds')

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">Disputes & Refunds</h4>
    </div>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <p class="text-muted">Refund approval and dispute resolution interface coming soon.</p>
        </div>
    </div>
</div>
@endsection
