<footer style="background: #333; color: white; padding: 30px; text-align: center; margin-top: 50px; border-top: 1px solid #444;">
    <div style="max-width: 1200px; margin: 0 auto;">
        <p style="margin: 0 0 10px 0; font-size: 14px;">© 2026 Business Management System. All Rights Reserved.</p>
        <p style="margin: 0; font-size: 12px; color: #999;">Developed with ❤️</p>
    </div>
</footer>
