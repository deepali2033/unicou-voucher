<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0">Low Stock Alerts</h4>
        <button class="btn btn-primary btn-sm">
            <i class="fas fa-bell me-1"></i> Notification Settings
        </button>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Voucher Type</th>
                            <th>Remaining Quantity</th>
                            <th>Threshold</th>
                            <th>Status</th>
                            <th>Auto Notification</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-bold text-dark"><?php echo e($alert['type']); ?></td>
                            <td>
                                <span class="badge <?php echo e($alert['remaining'] <= $alert['threshold'] ? 'bg-danger' : 'bg-success'); ?>">
                                    <?php echo e($alert['remaining']); ?>

                                </span>
                            </td>
                            <td><?php echo e($alert['threshold']); ?></td>
                            <td>
                                <?php if($alert['remaining'] <= $alert['threshold']): ?>
                                    <span class="text-danger small fw-bold"><i class="fas fa-exclamation-triangle me-1"></i> Low Stock</span>
                                    <?php else: ?>
                                    <span class="text-success small fw-bold">Good</span>
                                    <?php endif; ?>
                            </td>
                            <td>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" checked>
                                </div>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary">Add Stock</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/stock/alerts.blade.php ENDPATH**/ ?>