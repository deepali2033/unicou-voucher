<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin Dashboard - UniCou</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom Admin CSS -->
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Parkinsans:wght@300..800&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container-fluid">
        <div class="row koa-sidebar-wrapper flex-lg-nowrap">
            <!-- Overlay -->
            <div id="overlay" class="overlay"></div>

            <!-- Sidebar -->
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-3 sidebar sidebar-hidden">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4 d-flex justify-content-between align-items-center px-3">
                        <a class="text-start" href="/">
                            <img src="/images/company_logo.png" class="dashboard-logo" alt=""> </a>
                        <button id="close-sidebar" class="btn btn-link text-dark d-lg-none">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <?php
                    $role = auth()->user()->account_type ?? null;
                    ?>

                    <ul class="nav flex-column gap-2">

                        
                        <?php if($role): ?>

                        <li class="nav-item">

                            <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(in_array($role, ['admin','manager'])): ?>
                        <li class="nav-item">

                            <a class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.users.management')); ?>">
                                <i class="fas fa-users me-2"></i> User Management
                            </a>
                        </li>

                        <?php endif; ?>
                        <?php if(in_array($role, ['admin','manager'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.kyc.compliance')); ?>">
                                <i class="fas fa-id-card me-2"></i> KYC & Compliance
                            </a>

                        </li>

                        <?php endif; ?>


                        
                        <?php if(in_array($role, ['admin','agent','reseller_agent'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.wallet.index')); ?>">
                                <i class="fas fa-wallet me-2"></i> Wallet / Store Credit
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if($role === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fas fa-university me-2"></i> Payments & Banking
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(in_array($role, ['admin','manager'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.vouchers.control')); ?>">
                                <i class="fas fa-ticket-alt me-2"></i> Voucher Management
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(in_array($role, ['admin','agent','support_team'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.orders.index')); ?>">
                                <i class="fas fa-truck me-2"></i> Orders & Delivery
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if($role === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.pricing.index')); ?>">
                                <i class="fas fa-tags me-2"></i> Pricing & Discounts
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(in_array($role, ['admin','manager','support_team'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.inventory.index')); ?>">
                                <i class="fas fa-boxes me-2"></i> Stock & Inventory
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(in_array($role, ['agent,manager,reseller_agent,support_team,student,admin'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fas fa-gavel me-2"></i> Disputes & Refunds
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if($role === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.reports.index')); ?>">
                                <i class="fas fa-chart-line me-2"></i> Reports & Analytics
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if($role === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.system.control') ? 'active' : ''); ?>" href="<?php echo e(route('admin.system.control')); ?>">
                                <i class="fas fa-cogs me-2"></i> System Control
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if($role === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.audit.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.audit.index')); ?>">
                                <i class="fas fa-clipboard-list me-2"></i> Audit & Logs
                            </a>
                        </li>
                        <?php endif; ?>

                    </ul>



                    <hr class="my-3" style="border-color: #495057;">

                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">
                                <i class="fas fa-external-link-alt me-2"></i>
                                View Website
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.notifications.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.notifications.index')); ?>">
                                <i class="fas fa-bell me-2"></i>
                                Notifications
                            </a>
                        </li>
                        <li class="nav-item">
                            <form method="POST" action="<?php echo e(route('auth.logout')); ?>" style="margin:0;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="nav-link"
                                    style="background:none;border:none;width:100%;text-align:left;cursor:pointer;padding:0.5rem 1rem;">
                                    <i class="fas fa-external-link-alt me-2"></i>
                                    Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="mobile-header text-end d-lg-none">
                <a class="text-start" href="/">
                    <img src="/images/company_logo.png" class="mobile-logo" alt=""> </a>
                <button id="open-sidebar" class="btn navbtn">
                    <i class="fas fa-bars"></i>
                </button>
            </div>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-9 px-md-4 main-content">

                <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>

            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script>
        const sidebar = document.getElementById('sidebar');
        const openSidebarBtn = document.getElementById('open-sidebar');
        const closeSidebarBtn = document.getElementById('close-sidebar');
        const overlay = document.getElementById('overlay');

        openSidebarBtn?.addEventListener('click', (e) => {
            e.stopPropagation();
            sidebar.classList.remove('sidebar-hidden');
            overlay.classList.add('overlay-active');
        });

        closeSidebarBtn?.addEventListener('click', (e) => {
            e.stopPropagation();
            sidebar.classList.add('sidebar-hidden');
            overlay.classList.remove('overlay-active');
        });

        overlay?.addEventListener('click', () => {
            sidebar.classList.add('sidebar-hidden');
            overlay.classList.remove('overlay-active');
        });
    </script>
</body>

</html><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>