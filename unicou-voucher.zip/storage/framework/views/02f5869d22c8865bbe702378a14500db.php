<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2 class="fw-bold text-dark">System Audit Logs</h2>
            <p class="text-muted">Track all administrative actions and system events.</p>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold">Recent Activities</h5>
            <span class="badge bg-primary"><?php echo e($logs->total()); ?> Total Logs</span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>User</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>IP Address</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php if($log->user): ?>
                                <div class="fw-bold"><?php echo e($log->user->name); ?></div>
                                <div class="small text-muted"><?php echo e($log->user->email); ?></div>
                                <?php else: ?>
                                <span class="text-muted">System / Unknown</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-info-subtle text-info px-3 py-2">
                                    <?php echo e($log->action); ?>

                                </span>
                            </td>
                            <td>
                                <div class="text-wrap" style="max-width: 400px;">
                                    <?php echo e($log->description); ?>

                                </div>
                            </td>
                            <td>
                                <code class="small"><?php echo e($log->ip_address); ?></code>
                            </td>
                            <td>
                                <div class="small text-muted">
                                    <?php echo e($log->created_at ? $log->created_at->format('d M Y, H:i:s') : 'N/A'); ?>

                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">No audit logs found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <?php echo e($logs->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/audit/index.blade.php ENDPATH**/ ?>