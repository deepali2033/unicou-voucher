<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <form id="filter-form" action="<?php echo e(route('admin.users.management')); ?>" method="GET" class="row g-3 align-items-center">
                        <div class="col-md-7">
                            <div class="btn-group flex-wrap cls_us_manage" role="group">
                                <a href="<?php echo e(route('admin.users.management', ['role' => 'all', 'search' => request('search')])); ?>"
                                    class="btn btn-outline-primary <?php echo e(request('role', 'all') == 'all' ? 'active' : ''); ?>">All</a>
                                <a href="<?php echo e(route('admin.users.management', ['role' => 'manager', 'search' => request('search')])); ?>"
                                    class="btn btn-outline-primary <?php echo e(request('role') == 'manager' ? 'active' : ''); ?>">Manager</a>
                                <a href="<?php echo e(route('admin.users.management', ['role' => 'support_team', 'search' => request('search')])); ?>"
                                    class="btn btn-outline-primary <?php echo e(request('role') == 'support_team' ? 'active' : ''); ?>">Support Team</a>
                                <a href="<?php echo e(route('admin.users.management', ['role' => 'student', 'search' => request('search')])); ?>"
                                    class="btn btn-outline-primary <?php echo e(request('role') == 'student' ? 'active' : ''); ?>">Student</a>
                                <a href="<?php echo e(route('admin.users.management', ['role' => 'reseller_agent', 'search' => request('search')])); ?>"
                                    class="btn btn-outline-primary <?php echo e(request('role') == 'reseller_agent' ? 'active' : ''); ?>">Reseller Agent</a>
                                <a href="<?php echo e(route('admin.users.management', ['role' => 'agent', 'search' => request('search')])); ?>"
                                    class="btn btn-outline-primary <?php echo e(request('role') == 'agent' ? 'active' : ''); ?>">Agent</a>
                            </div>
                        </div>
                        <input type="hidden" name="role" value="<?php echo e(request('role', 'all')); ?>">
                        <div class="col-md-3">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Search by name..." value="<?php echo e(request('search')); ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-2 text-end d-flex gap-2 cls_us_mng_btns">
                            <a href="<?php echo e(route('admin.users.pdf', ['role' => request('role'), 'search' => request('search')])); ?>" class="btn btn-danger flex-fill">
                                <i class="fas fa-file-pdf"></i> PDF
                            </a>
                            <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success flex-fill">
                                <i class="fas fa-plus"></i> Add
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold">User Management</h5>
            <span class="badge bg-primary total-count"><?php echo e($users->total()); ?> Total Users</span>
        </div>
        <div class="card-body" id="table-container">
            <?php echo $__env->make('admin.partials.users-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        function updateTable(url) {
            $.ajax({
                url: url,
                success: function(data) {
                    $('#table-container').html(data);
                    // Update URL without reload
                    window.history.pushState({}, '', url);
                }
            });
        }

        // Handle Pagination
        $(document).on('click', '.ajax-pagination a', function(e) {
            e.preventDefault();
            updateTable($(this).attr('href'));
        });

        // Handle Filters & Search
        $('#filter-form').on('submit', function(e) {
            e.preventDefault();
            let url = $(this).attr('action') + '?' + $(this).serialize();
            updateTable(url);
        });

        $('.btn-group a').on('click', function(e) {
            e.preventDefault();
            $('.btn-group a').removeClass('active');
            $(this).addClass('active');
            updateTable($(this).attr('href'));
        });

        // Handle AJAX Actions (Suspend, Delete)
        $(document).on('submit', '.ajax-action', function(e) {
            e.preventDefault();
            let form = $(this);
            let url = form.attr('action');
            let method = form.find('input[name="_method"]').val() || 'POST';

            if (method === 'DELETE' && !confirm('Are you sure you want to delete this?')) {
                return;
            }

            $.ajax({
                url: url,
                method: method,
                data: form.serialize(),
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.success);
                        // Refresh table with current filters
                        updateTable(window.location.href);
                    }
                },
                error: function(xhr) {
                    toastr.error('Something went wrong. Please try again.');
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/user-managment.blade.php ENDPATH**/ ?>