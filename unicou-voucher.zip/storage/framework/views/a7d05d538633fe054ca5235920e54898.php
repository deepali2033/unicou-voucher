<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>User Info</th>
                <th>Role</th>
                <th>Email Verification</th>
                <th>Status</th>
                <th>Created At</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e($user->profile_photo ? asset('storage/' . $user->profile_photo) : asset('images/user.png')); ?>"
                            class="rounded-circle me-3" width="40" height="40"
                            style="object-fit: cover; border: 1px solid #eee;">
                        <div>
                            <div class="fw-bold text-dark">
                                <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                            </div>
                            <div class="text-muted small">
                                <div class="user_id"><?php echo e($user->user_id); ?></div>
                                <div class="user_id_email"><?php echo e($user->email); ?></div>
                            </div>
                        </div>
                    </div>
                </td>

                <td>
                    <span class="badge bg-light text-dark border px-3 py-2">
                        <?php echo e(ucfirst(str_replace('_', ' ', $user->account_type))); ?>

                    </span>
                </td>

                <td>
                    <?php if($user->email_verified_at): ?>
                    <span class="badge bg-success-subtle text-success px-3 py-2">
                        <i class="fas fa-check-circle me-1"></i> Verified
                    </span>
                    <?php else: ?>
                    <span class="badge bg-danger-subtle text-danger px-3 py-2">
                        <i class="fas fa-times-circle me-1"></i> Not Verified
                    </span>
                    <?php endif; ?>
                </td>

                <td>
                    <span
                        class="badge px-3 py-2 user-status-toggle
                       <?php echo e($user->is_active ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'); ?>"
                        data-id="<?php echo e($user->id); ?>"
                        style="cursor:pointer;"
                        title="Click to <?php echo e($user->is_active ? 'freeze' : 'unfreeze'); ?>">
                        <?php if($user->is_active): ?>
                        <i class="fas fa-unlock me-1"></i> Active
                        <?php else: ?>
                        <i class="fas fa-lock me-1"></i> Frozen
                        <?php endif; ?>
                    </span>
                </td>


                <td>
                    <div class="small text-muted">
                        <?php echo e($user->created_at ? $user->created_at->format('d M Y') : 'N/A'); ?>

                    </div>
                </td>

                
                <td class="text-end">
                    <div class="d-flex justify-content-end gap-1">
                        <a class="btn btn-sm btn-light"
                            href="<?php echo e(route('admin.users.show', $user->id)); ?>" title="View">
                            <i class="fas fa-eye text-primary"></i>
                        </a>

                        <a class="btn btn-sm btn-light"
                            href="<?php echo e(route('admin.users.edit', $user->id)); ?>" title="Edit">
                            <i class="fas fa-edit text-info"></i>
                        </a>

                        <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="ajax-action">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-light" title="Delete">
                                <i class="fas fa-trash text-danger"></i>
                            </button>
                        </form>



                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center py-5 text-muted">
                    No users found.
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/partials/users-table.blade.php ENDPATH**/ ?>