<?php $__env->startSection('content'); ?>
<div class="container-fluid">


    <div class="card shadow-sm border-0">
        <div class="card-header ">


            <h5 class="mb-0 fw-bold">Support Center</h5>
            <small class="text-muted"> Browse through our frequently asked questions or search a query and describe <br>
                your problem in detail. Our team will get back to you as soon as possible.</small>


        </div>
        <div class="card shadow-sm border-0 p-4" style="border-radius: 15px;">
            <form action="<?php echo e(route('customer.support.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <select name="topic" id="topicSelect" class="form-select form-select-lg border-0 shadow-sm p-3 custom-select" style="border-radius: 10px; background-color: #f8f9fa;" required>
                        <option value="" selected disabled>Select Your Query</option>
                        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($topic->id); ?>"><?php echo e($topic->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <select name="issue" id="issueSelect" class="form-select form-select-lg border-0 shadow-sm p-3 custom-select" style="border-radius: 10px; background-color: #f8f9fa;" required disabled>
                        <option value="" selected disabled>Select Subcategory</option>
                    </select>
                    <?php $__errorArgs = ['issue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold text-dark">Description :</label>
                    <textarea name="description" class="form-control border-0 shadow-sm p-4" rows="6" placeholder="Describe your problem in details .." style="border-radius: 10px; background-color: #f8f9fa;" required></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="text-end">
                    <button type="submit" class="btn btn-lg px-5 py-3 text-white fw-bold submit-btn" style="border-radius: 10px; background-color: #d63384;">
                        Submit Query
                    </button>
                </div>
            </form>
        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('#topicSelect').on('change', function() {
        const topicId = $(this).val();
        const issueSelect = $('#issueSelect');
        
        issueSelect.prop('disabled', true).html('<option value="" selected disabled>Loading...</option>');
        
        if (topicId) {
            $.ajax({
                url: "<?php echo e(route('support.options.issues', ':id')); ?>".replace(':id', topicId),
                method: "GET",
                success: function(data) {
                    issueSelect.html('<option value="" selected disabled>Select Subcategory</option>');
                    data.forEach(function(issue) {
                        issueSelect.append(`<option value="${issue.id}">${issue.name}</option>`);
                    });
                    issueSelect.prop('disabled', false);
                },
                error: function() {
                    toastr.error('Failed to load subcategories');
                    issueSelect.html('<option value="" selected disabled>Select Subcategory</option>');
                }
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/dashboard/Customer-support/cust-query.blade.php ENDPATH**/ ?>