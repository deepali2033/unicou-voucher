<?php $__env->startSection('content'); ?>
<div class="container-fluid">


    <div class="card shadow-sm border-0">
        <div class="card-header ">


            <h5 class="mb-0 fw-bold">Support Center</h5>
            <small class="text-muted"> Browse through our frequently asked questions or search a query and describe <br>
                your problem in detail. Our team will get back to you as soon as possible.</small>


        </div>
        <div class="card shadow-sm border-0 p-4" style="border-radius: 15px;">
            <form action="<?php echo e(route('customer.support.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-4 cls_Support_Center_select">
                    <select name="topic" class="form-select form-select-lg border-0 shadow-sm p-3 custom-select" style="border-radius: 10px; background-color: #f8f9fa;" required>
                        <option value="" selected disabled>Select Your Query</option>
                        <option value="Booking Process">Booking Process</option>
                        <option value="Payment Issue">Payment Issue</option>
                        <option value="Technical Support">Technical Support</option>
                        <option value="Account Access">Account Access</option>
                    </select>
                    <?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4 cls_Support_Center_select">
                    <select name="issue" class="form-select form-select-lg border-0 shadow-sm p-3 custom-select" style="border-radius: 10px; background-color: #f8f9fa;" required>
                        <option value="" selected disabled>Select Subcategory</option>
                        <option value="No exams found">No exams found</option>
                        <option value="Voucher not working">Voucher not working</option>
                        <option value="Location mismatch">Location mismatch</option>
                        <option value="Other Issue">Other Issue</option>
                    </select>
                    <?php $__errorArgs = ['issue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold text-dark">Description :</label>
                    <textarea name="description" class="form-control border-0 shadow-sm p-4" rows="6" placeholder="Describe your problem in details .." style="border-radius: 10px; background-color: #f8f9fa;" required></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="text-end">
                    <button type="submit" class="btn btn-lg px-5 py-3 text-white fw-bold submit-btn" style="border-radius: 10px; background-color: #d63384;">
                        Submit Query
                    </button>
                </div>
            </form>
        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/dashboard/Customer-support/add-query.blade.php ENDPATH**/ ?>