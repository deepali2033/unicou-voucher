<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0">Approval Requests</h4>
        <span class="badge bg-warning text-dark"><?php echo e($pendingUsers->count()); ?> Pending</span>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>User Info</th>
                            <th>Role</th>
                            <th>Registration Details</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pendingUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="fw-bold text-dark"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></div>
                                </div>
                                <div class="text-muted small"><?php echo e($user->email); ?></div>
                                <div class="text-muted small"><?php echo e($user->user_id); ?></div>
                            </td>
                            <td>
                                <span class="badge rounded-pill bg-info-subtle text-info border border-info-subtle px-3">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $user->account_type))); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($user->account_type === 'reseller_agent' && $user->agentDetail): ?>
                                    <div class="small"><strong>Business:</strong> <?php echo e($user->agentDetail->business_name); ?></div>
                                    <div class="small text-muted">Type: <?php echo e($user->agentDetail->business_type); ?></div>
                                <?php elseif($user->account_type === 'student' && $user->studentDetail): ?>
                                    <div class="small"><strong>Student:</strong> <?php echo e($user->studentDetail->full_name); ?></div>
                                    <div class="small text-muted">Education: <?php echo e($user->studentDetail->highest_education); ?></div>
                                <?php else: ?>
                                    <span class="text-muted small">No details provided</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <div class="d-flex justify-content-end gap-2">
                                    <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="btn btn-sm btn-outline-primary">
                                        View Details
                                    </a>
                                    <form action="<?php echo e(route('admin.approvals.approve', $user->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Approve this user?')">
                                            <i class="fas fa-check me-1"></i> Approve
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="fas fa-user-clock fa-3x mb-3"></i>
                                    <p>No pending approval requests found.</p>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/approvals/index.blade.php ENDPATH**/ ?>