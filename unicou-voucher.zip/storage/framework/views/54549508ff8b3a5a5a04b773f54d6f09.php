<style>
    .v-card {
        background: #fff;
        border-radius: 20px;
        padding: 1.5rem;
        border: none;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        transition: transform 0.2s;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .v-card:hover { transform: translateY(-5px); }
    .v-logo {
        width: 80px;
        height: 80px;
        object-fit: contain;
        margin-right: 1.5rem;
    }
    .v-title {
        font-size: 16px;
        font-weight: 700;
        color: #333;
        margin-bottom: 0.5rem;
    }
    .v-price {
        font-size: 20px;
        font-weight: 800;
        color: #1a1a1a;
    }
    .v-old-price {
        font-size: 14px;
        color: #ef4444;
        text-decoration: line-through;
        margin-left: 0.5rem;
    }
    .v-btn-edit {
        background: #3b82f6;
        color: #fff;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 1.5rem;
        font-weight: 600;
        flex: 1;
    }
    .v-btn-edit:hover { color: #fff; background: #2563eb; }
    .v-btn-del {
        background: transparent;
        border: 1px solid #ef4444;
        color: #ef4444;
        border-radius: 8px;
        width: 42px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .v-btn-del:hover { background: #fee2e2; color: #ef4444; }
    .v-footer {
        margin-top: auto;
        padding-top: 1rem;
        border-top: 1px solid #f3f4f6;
        display: flex;
        justify-content: space-between;
        font-size: 13px;
        font-weight: 600;
        color: #6b7280;
    }
</style>

<div class="row g-4">
    <?php $__empty_1 = true; $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6 col-lg-4">
        <div class="v-card">
            <div class="d-flex mb-3">
                <?php if($v->logo): ?>
                    <img src="<?php echo e($v->logo); ?>" class="v-logo" alt="Logo">
                <?php else: ?>
                    <div class="v-logo d-flex flex-column align-items-center justify-content-center bg-light text-muted" style="border-radius: 10px;">
                        <i class="fas fa-image fa-2x mb-1"></i>
                        <small style="font-size: 10px;">No Logo</small>
                    </div>
                <?php endif; ?>
                <div class="flex-grow-1">
                    <h5 class="v-title"><?php echo e($v->brand_name); ?></h5>
                    <div class="d-flex align-items-baseline mb-3">
                        <span class="v-price"><?php echo e($v->currency); ?> <?php echo e(number_format($v->agent_sale_price)); ?></span>
                        <?php if($v->original_price > 0): ?>
                            <span class="v-old-price"><?php echo e($v->currency); ?> <?php echo e(number_format($v->original_price)); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('admin.inventory.edit', $v->id)); ?>" class="v-btn-edit text-center text-decoration-none">
                            <i class="fas fa-edit me-1"></i> Edit
                        </a>
                        <button type="button" class="v-btn-del delete-voucher-btn" data-id="<?php echo e($v->id); ?>">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="v-footer">
                <div class="d-flex align-items-center">
                    <span class="me-1">🎓</span>
                    <?php echo e($v->quarterly_points); ?> Quarterly
                </div>
                <div class="d-flex align-items-center">
                    <span class="me-1">🏷️</span>
                    <?php echo e($v->yearly_points); ?> Yearly
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12 text-center py-5">
        <h5 class="text-muted">No vouchers found</h5>
    </div>
    <?php endif; ?>
</div>

<div class="mt-4 ajax-pagination">
    <?php echo e($vouchers->links()); ?>

</div>
<?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/inventory/partials/voucher-list.blade.php ENDPATH**/ ?>