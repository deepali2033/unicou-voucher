  <!-- Sidebar -->
  <nav id="sidebar" class="col-md-3 col-lg-3 sidebar sidebar-hidden">
      <div class="position-sticky pt-3">
          <div class="text-center mb-4 d-flex justify-content-between align-items-center px-3">
              <a class="text-start" href="/">
                  <img src="/images/company_logo.png" class="dashboard-logo" alt=""> </a>
              <button id="close-sidebar" class="btn btn-link text-dark d-lg-none">
                  <i class="fas fa-times"></i>
              </button>
          </div>
          <?php
          $role = auth()->user()->account_type ?? null;
          ?>
          <ul class="nav flex-column gap-2">

              
              <?php if($role): ?>

              <li class="nav-item">

                  <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
                      href="<?php echo e(route('admin.dashboard')); ?>">
                      <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if(in_array($role, ['admin','manager'])): ?>
              <li class="nav-item">

                  <a class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>"
                      href="<?php echo e(route('admin.users.management')); ?>">
                      <i class="fas fa-users me-2"></i> User Management
                  </a>
              </li>

              <?php endif; ?>
              <?php if(in_array($role, ['admin','manager'])): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.kyc.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.kyc.compliance')); ?>">
                      <i class="fas fa-id-card me-2"></i> KYC & Compliance
                  </a>

              </li>

              <?php endif; ?>


              
              <?php if(in_array($role, ['admin','agent','reseller_agent'])): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.wallet.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.wallet.index')); ?>">
                      <i class="fas fa-wallet me-2"></i> Wallet / Store Credit
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if($role === 'admin'): ?>
              <li class="nav-item">
                  <a class="nav-link" href="#">
                      <i class="fas fa-university me-2"></i> Payments & Banking
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if(in_array($role, ['admin','manager'])): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.vouchers.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.vouchers.control')); ?>">
                      <i class="fas fa-ticket-alt me-2"></i> Voucher Management
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if(in_array($role, ['admin','agent','support_team'])): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.orders.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.orders.index')); ?>">
                      <i class="fas fa-truck me-2"></i> Orders & Delivery
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if($role === 'admin'): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.pricing.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.pricing.index')); ?>">
                      <i class="fas fa-tags me-2"></i> Pricing & Discounts
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if(in_array($role, ['admin','manager','support_team'])): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.inventory.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.inventory.index')); ?>">
                      <i class="fas fa-boxes me-2"></i> Stock & Inventory
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if(in_array($role, ['agent,manager,reseller_agent,support_team,student,admin'])): ?>
              <li class="nav-item">
                  <a class="nav-link" href="#">
                      <i class="fas fa-gavel me-2"></i> Disputes & Refunds
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if($role === 'admin'): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.reports.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.reports.index')); ?>">
                      <i class="fas fa-chart-line me-2"></i> Reports & Analytics
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if($role === 'admin'): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.system.control') ? 'active' : ''); ?>" href="<?php echo e(route('admin.system.control')); ?>">
                      <i class="fas fa-cogs me-2"></i> System Control
                  </a>
              </li>
              <?php endif; ?>

              
              <?php if($role === 'admin'): ?>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.audit.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.audit.index')); ?>">
                      <i class="fas fa-clipboard-list me-2"></i> Audit & Logs
                  </a>
              </li>
              <?php endif; ?>

          </ul>



          <hr class="my-3" style="border-color: #495057;">

          <ul class="nav flex-column">
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">
                      <i class="fas fa-external-link-alt me-2"></i>
                      View Website
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link <?php echo e(request()->routeIs('admin.notifications.*') ? 'active' : ''); ?>"
                      href="<?php echo e(route('admin.notifications.index')); ?>">
                      <i class="fas fa-bell me-2"></i>
                      Notifications
                  </a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('auth.logout')); ?>" 
                     onclick="event.preventDefault(); document.getElementById('logout-form-sidebar').submit();">
                      <i class="fas fa-sign-out-alt me-2"></i> Logout
                  </a>
                  <form id="logout-form-sidebar" action="<?php echo e(route('auth.logout')); ?>" method="POST" class="d-none">
                      <?php echo csrf_field(); ?>
                  </form>
              </li>
          </ul>
      </div>
  </nav><?php /**PATH C:\Users\admin\Documents\GitHub\unicou-voucher\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>