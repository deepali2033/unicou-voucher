<?php

return [
    App\Providers\LocationServiceProvider::class,
    App\Providers\ViewServiceProvider::class,
];
